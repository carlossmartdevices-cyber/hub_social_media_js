require('dotenv').config();

const TelegramBot = require('node-telegram-bot-api');
const HubManager = require('./core/hubManager');
const ContentScheduler = require('./core/contentScheduler');
const TelegramAPIClient = require('./platforms/telegram/apiClient');
const TelegramMessageManager = require('./platforms/telegram/messageManager');
const TelegramLiveManager = require('./platforms/telegram/liveManager');
const TwitterAPIClient = require('./platforms/twitter/apiClient');
const Logger = require('./utils/logger');
const { LanguageManager } = require('./utils/languageManager');
const InlineMenuManager = require('./utils/inlineMenuManager');
const dbConnection = require('./database/dbConnection');
const { ScheduledContent } = require('./database/models');
const { handleError } = require('./utils/errorHandler');

const logger = new Logger();

async function initializeDatabase() {
  try {
    await dbConnection.testConnection();
    await dbConnection.sync({ alter: process.env.NODE_ENV === 'development' });
    logger.info('Database synchronized successfully');
  } catch (error) {
    logger.error('Database initialization failed', error);
    throw error;
  }
}

class EnhancedBotManager {
  constructor() {
    this.hub = null;
    this.scheduler = null;
    this.telegramClient = null;
    this.telegramMessageManager = null;
    this.telegramLiveManager = null;
    this.twitterClient = null;
    this.menuManager = new InlineMenuManager();
    this.bot = null;
    this.isRunning = false;
  }

  async initialize() {
    try {
      // Initialize database first
      await initializeDatabase();

      // Initialize core components
      this.hub = new HubManager();
      this.scheduler = new ContentScheduler(this.hub);

      // Initialize Telegram components if token is available
      if (process.env.TELEGRAM_BOT_TOKEN) {
        this.telegramClient = new TelegramAPIClient();
        this.telegramMessageManager = new TelegramMessageManager();
        this.telegramLiveManager = new TelegramLiveManager();
        
        // Initialize bot with polling
        this.bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, { polling: true });
        
        // Test Telegram connection
        const botInfo = await this.telegramClient.getBotInfo();
        logger.info(`Telegram Bot initialized: @${botInfo.username} - ${botInfo.first_name}`);
      } else {
        logger.warn('Telegram Bot Token not found. Telegram functionality disabled.');
      }

      // Initialize Twitter if configured
      if (process.env.TWITTER_API_KEY) {
        this.twitterClient = new TwitterAPIClient();
        logger.info('Twitter API client initialized');
      }

      logger.info('Enhanced Bot Manager initialized successfully');
      return true;
    } catch (error) {
      logger.error('Failed to initialize Enhanced Bot Manager', error);
      throw error;
    }
  }

  async startEnhancedInteractiveMode() {
    if (!this.bot) {
      logger.error('Telegram not configured. Please set TELEGRAM_BOT_TOKEN in .env file');
      return;
    }

    logger.info('🚀 Starting Enhanced Telegram Bot with Inline Menus...');
    logger.info('✨ New Features:');
    logger.info('  • Comprehensive inline menu system');
    logger.info('  • Quick actions and easy navigation');
    logger.info('  • Improved user experience');
    logger.info('  • Multi-step workflows');
    logger.info('');
    logger.info('Available commands:');
    logger.info('• /start - Show main menu with all options');
    logger.info('• /menu - Quick access to main menu');
    logger.info('• /quick - Show quick actions menu');
    logger.info('• /lang - Change language (Spanish/English)');
    logger.info('• /help - Show help information');
    logger.info('');
    logger.info('🎯 Enhanced Bot is now running!');

    this.isRunning = true;
    this.setupEventHandlers();
  }

  setupEventHandlers() {
    // Handle /start command - Show main menu
    this.bot.onText(/\/start/, async (msg) => {
      const chatId = msg.chat.id;
      await this.showMainMenu(chatId);
    });

    // Handle /menu command - Quick access to main menu
    this.bot.onText(/\/menu/, async (msg) => {
      const chatId = msg.chat.id;
      await this.showMainMenu(chatId);
    });

    // Handle /quick command - Quick actions
    this.bot.onText(/\/quick/, async (msg) => {
      const chatId = msg.chat.id;
      await this.showQuickActions(chatId);
    });

    // Handle /lang command for language switching
    this.bot.onText(/\/lang/, async (msg) => {
      const chatId = msg.chat.id;
      await this.showLanguageMenu(chatId);
    });

    // Handle /help command
    this.bot.onText(/\/help/, async (msg) => {
      const chatId = msg.chat.id;
      const helpMessage = LanguageManager.getHelpMessage(chatId);
      
      try {
        await this.bot.sendMessage(chatId, helpMessage, {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '🏠 Main Menu', callback_data: 'menu_main' }]
            ]
          }
        });
      } catch (error) {
        logger.error(`Failed to send help message to ${chatId}`, error);
      }
    });

    // Handle callback queries (inline button presses)
    this.bot.on('callback_query', async (callbackQuery) => {
      await this.handleCallbackQuery(callbackQuery);
    });

    // Handle text messages for multi-step processes
    this.bot.on('message', async (msg) => {
      // Skip if it's a command (already handled above)
      if (msg.text && msg.text.startsWith('/')) {
        return;
      }

      const chatId = msg.chat.id;
      const userState = this.menuManager.getUserState(chatId);

      if (userState) {
        await this.handleUserInput(msg, userState);
      } else {
        // For new users or when no state, show main menu
        await this.showMainMenu(chatId, 'Let me help you get started! 🚀');
      }
    });

    // Handle errors
    this.bot.on('error', (error) => {
      logger.error('Telegram Bot error:', error);
    });

    this.bot.on('polling_error', (error) => {
      logger.error('Telegram Bot polling error:', error);
    });

    // Handle graceful shutdown
    process.on('SIGINT', async () => {
      logger.info('Stopping Enhanced Telegram Bot...');
      if (this.bot) {
        this.bot.stopPolling();
      }
      this.isRunning = false;
      await this.shutdown();
    });
  }

  async showMainMenu(chatId, customMessage = null) {
    try {
      const menu = this.menuManager.getMainMenu(chatId);
      const message = customMessage || menu.text;
      
      await this.bot.sendMessage(chatId, message, {
        parse_mode: 'HTML',
        ...this.menuManager.generateKeyboard(menu.keyboard)
      });
      
      logger.info(`Main menu shown to chat ${chatId}`);
    } catch (error) {
      logger.error(`Failed to show main menu to ${chatId}`, error);
    }
  }

  async showQuickActions(chatId) {
    try {
      const menu = this.menuManager.getQuickActionsMenu(chatId);
      
      await this.bot.sendMessage(chatId, menu.text, {
        parse_mode: 'HTML',
        ...this.menuManager.generateKeyboard(menu.keyboard)
      });
      
      logger.info(`Quick actions shown to chat ${chatId}`);
    } catch (error) {
      logger.error(`Failed to show quick actions to ${chatId}`, error);
    }
  }

  async showLanguageMenu(chatId, messageId = null) {
    try {
      const menu = this.menuManager.getLanguageMenu(chatId);
      
      if (messageId) {
        // Edit existing message
        await this.bot.editMessageText(menu.text, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          ...this.menuManager.generateKeyboard(menu.keyboard)
        });
      } else {
        // Send new message
        await this.bot.sendMessage(chatId, menu.text, {
          parse_mode: 'HTML',
          ...this.menuManager.generateKeyboard(menu.keyboard)
        });
      }
      
      logger.info(`Language menu shown to chat ${chatId}`);
    } catch (error) {
      logger.error(`Failed to show language menu to ${chatId}`, error);
    }
  }

  async handleCallbackQuery(callbackQuery) {
    const chatId = callbackQuery.message.chat.id;
    const messageId = callbackQuery.message.message_id;
    const data = callbackQuery.data;

    try {
      // Answer the callback query first
      await this.bot.answerCallbackQuery(callbackQuery.id);

      // Handle different callback types
      if (data === 'menu_language') {
        await this.showLanguageMenu(chatId, messageId);
      } else if (data.startsWith('menu_')) {
        await this.handleMenuNavigation(chatId, messageId, data);
      } else if (data.startsWith('lang_')) {
        await this.handleLanguageChange(chatId, messageId, data);
      } else if (data.startsWith('post_')) {
        await this.handlePostAction(chatId, messageId, data);
      } else if (data.startsWith('schedule_')) {
        await this.handleScheduleAction(chatId, messageId, data);
      } else if (data.startsWith('live_')) {
        await this.handleLiveAction(chatId, messageId, data);
      } else if (data.startsWith('quick_')) {
        await this.handleQuickAction(chatId, messageId, data);
      } else if (data.startsWith('platform_')) {
        await this.handlePlatformSelection(chatId, messageId, data);
      } else if (data.startsWith('time_')) {
        await this.handleTimeSelection(chatId, messageId, data);
      } else if (data.startsWith('confirm_')) {
        await this.handleConfirmation(chatId, messageId, data);
      } else {
        // Default to main menu for unknown callbacks
        await this.showMainMenu(chatId);
      }

      logger.info(`Callback query handled: ${data} from chat ${chatId}`);
    } catch (error) {
      logger.error(`Failed to handle callback query ${data} from ${chatId}`, error);
    }
  }

  async handleMenuNavigation(chatId, messageId, data) {
    const menu = this.menuManager.getMenuByCallback(chatId, data);
    
    if (typeof menu === 'string') {
      // It's a help message
      await this.bot.editMessageText(menu, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🏠 Main Menu', callback_data: 'menu_main' }]
          ]
        }
      });
    } else {
      // It's a menu object
      await this.bot.editMessageText(menu.text, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        ...this.menuManager.generateKeyboard(menu.keyboard)
      });
    }
  }

  async handleLanguageChange(chatId, messageId, data) {
    const newLang = data.split('_')[1];
    LanguageManager.setUserLanguage(chatId, newLang);
    
    const confirmMessage = LanguageManager.getLanguageChangedMessage(newLang);
    
    // First show confirmation message
    await this.bot.editMessageText(confirmMessage, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML'
    });
    
    // Wait a moment then show main menu in new language
    setTimeout(async () => {
      try {
        const mainMenu = this.menuManager.getMainMenu(chatId);
        await this.bot.editMessageText(mainMenu.text, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          ...this.menuManager.generateKeyboard(mainMenu.keyboard)
        });
      } catch (error) {
        logger.error(`Failed to show main menu after language change`, error);
        // If editing fails, send a new message
        await this.showMainMenu(chatId);
      }
    }, 1500);
    
    logger.info(`Language changed to ${newLang} for chat ${chatId}`);
  }

  async handlePostAction(chatId, messageId, data) {
    const action = data.replace('post_', '');
    
    if (action === 'all') {
      // Set state for multi-platform posting
      this.menuManager.setUserState(chatId, 'awaiting_content', { 
        action: 'post_all',
        platforms: ['twitter', 'telegram', 'instagram', 'tiktok']
      });
      
      const lang = LanguageManager.getUserLanguage(chatId);
      const message = lang === 'es' ? 
        '📝 Envía el contenido que quieres publicar en todas las plataformas:' :
        '📝 Send the content you want to post to all platforms:';
      
      await this.bot.editMessageText(message, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '❌ Cancel', callback_data: 'menu_main' }]
          ]
        }
      });
    } else {
      // Single platform posting
      this.menuManager.setUserState(chatId, 'awaiting_content', { 
        action: `post_${action}`,
        platform: action
      });
      
      const lang = LanguageManager.getUserLanguage(chatId);
      const platformNames = {
        twitter: 'Twitter/X',
        telegram: 'Telegram',
        instagram: 'Instagram',
        tiktok: 'TikTok'
      };
      
      const message = lang === 'es' ? 
        `📝 Envía el contenido que quieres publicar en ${platformNames[action]}:` :
        `📝 Send the content you want to post to ${platformNames[action]}:`;
      
      await this.bot.editMessageText(message, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '❌ Cancel', callback_data: 'menu_main' }]
          ]
        }
      });
    }
  }

  async handleScheduleAction(chatId, messageId, data) {
    const action = data.replace('schedule_', '');
    
    switch (action) {
      case 'later':
        const timeMenu = this.menuManager.getTimeMenu(chatId);
        await this.bot.editMessageText(timeMenu.text, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          ...this.menuManager.generateKeyboard(timeMenu.keyboard)
        });
        break;
        
      case 'view':
        await this.showScheduledContent(chatId, messageId);
        break;
        
      case 'cancel':
        await this.showCancelScheduledContent(chatId, messageId);
        break;
        
      default:
        await this.showMainMenu(chatId);
    }
  }

  async handleLiveAction(chatId, messageId, data) {
    const action = data.replace('live_', '');
    
    switch (action) {
      case 'start':
        await this.startLiveStream(chatId, messageId);
        break;
        
      case 'end':
        await this.endLiveStream(chatId, messageId);
        break;
        
      case 'update':
        await this.sendLiveUpdate(chatId, messageId);
        break;
        
      case 'view':
        await this.viewActiveStreams(chatId, messageId);
        break;
        
      case 'invite':
        await this.createInviteLink(chatId, messageId);
        break;
        
      default:
        await this.showMainMenu(chatId);
    }
  }

  async handleQuickAction(chatId, messageId, data) {
    const action = data.replace('quick_', '');

    switch (action) {
      case 'post':
        // Quick post to Twitter
        this.menuManager.setUserState(chatId, 'awaiting_content', {
          action: 'quick_post',
          platform: 'twitter'
        });

        const lang = LanguageManager.getUserLanguage(chatId);
        const message = lang === 'es' ?
          '⚡ Envía tu mensaje para publicación rápida en Twitter:' :
          '⚡ Send your message for quick Twitter post:';

        await this.bot.editMessageText(message, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '❌ Cancel', callback_data: 'menu_main' }]
            ]
          }
        });
        break;

      case 'status':
        await this.showQuickStatus(chatId, messageId);
        break;

      default:
        await this.showMainMenu(chatId);
    }
  }

  async handlePlatformSelection(chatId, messageId, data) {
    // Extract platform and action from callback data
    // Format: platform_<platform>_<action>
    const parts = data.replace('platform_', '').split('_');
    const platform = parts[0];
    const action = parts[1] || 'post';

    const lang = LanguageManager.getUserLanguage(chatId);

    if (action === 'post') {
      // Set state for posting to selected platform
      this.menuManager.setUserState(chatId, 'awaiting_content', {
        action: `post_${platform}`,
        platform: platform
      });

      const platformNames = {
        twitter: 'Twitter/X',
        telegram: 'Telegram',
        instagram: 'Instagram',
        tiktok: 'TikTok',
        all: lang === 'es' ? 'todas las plataformas' : 'all platforms'
      };

      const message = lang === 'es' ?
        `📝 Envía el contenido que quieres publicar en ${platformNames[platform]}:` :
        `📝 Send the content you want to post to ${platformNames[platform]}:`;

      await this.bot.editMessageText(message, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: lang === 'es' ? '❌ Cancelar' : '❌ Cancel', callback_data: 'menu_main' }]
          ]
        }
      });
    } else {
      // Handle other actions (schedule, view, etc.)
      await this.showMainMenu(chatId);
    }
  }

  async handleTimeSelection(chatId, messageId) {
    const lang = LanguageManager.getUserLanguage(chatId);

    // For now, show a message that scheduling is being implemented
    const message = lang === 'es' ?
      '⏰ La función de programación estará disponible pronto.\n\nPor ahora, puedes publicar contenido de inmediato.' :
      '⏰ Scheduling feature coming soon.\n\nFor now, you can post content immediately.';

    await this.bot.editMessageText(message, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: lang === 'es' ? '🔙 Volver' : '🔙 Back', callback_data: 'menu_main' }]
        ]
      }
    });
  }

  async handleConfirmation(chatId, messageId, data) {
    const lang = LanguageManager.getUserLanguage(chatId);
    const parts = data.replace('confirm_', '').split('_');
    const confirmation = parts[0]; // 'yes' or 'no'

    if (confirmation === 'yes') {
      // Process the confirmed action
      const message = lang === 'es' ?
        '✅ Acción confirmada y procesada.' :
        '✅ Action confirmed and processed.';

      await this.bot.editMessageText(message, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: lang === 'es' ? '🏠 Menú Principal' : '🏠 Main Menu', callback_data: 'menu_main' }]
          ]
        }
      });
    } else {
      // Action cancelled
      const message = lang === 'es' ?
        '❌ Acción cancelada.' :
        '❌ Action cancelled.';

      await this.bot.editMessageText(message, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: lang === 'es' ? '🏠 Menú Principal' : '🏠 Main Menu', callback_data: 'menu_main' }]
          ]
        }
      });
    }
  }

  async handleUserInput(msg, userState) {
    const chatId = msg.chat.id;
    const text = msg.text;
    
    if (userState.state === 'awaiting_content') {
      await this.processContentInput(chatId, text, userState.data);
      this.menuManager.clearUserState(chatId);
    }
  }

  async processContentInput(chatId, content, actionData) {
    const lang = LanguageManager.getUserLanguage(chatId);
    
    try {
      if (actionData.action === 'post_all') {
        // Post to all platforms
        const results = [];
        
        if (this.twitterClient) {
          try {
            const result = await this.twitterClient.sendMessage(content);
            results.push(`✅ Twitter: Posted successfully`);
          } catch (error) {
            results.push(`❌ Twitter: ${error.message}`);
          }
        }
        
        if (this.telegramClient && process.env.TELEGRAM_DEFAULT_CHAT_ID) {
          try {
            await this.telegramMessageManager.sendTextMessage(
              process.env.TELEGRAM_DEFAULT_CHAT_ID, 
              content
            );
            results.push(`✅ Telegram: Posted successfully`);
          } catch (error) {
            results.push(`❌ Telegram: ${error.message}`);
          }
        }
        
        const summary = results.join('\n');
        const message = lang === 'es' ? 
          `📊 <b>Resultados de publicación:</b>\n\n${summary}` :
          `📊 <b>Publishing Results:</b>\n\n${summary}`;
        
        await this.bot.sendMessage(chatId, message, {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '🏠 Main Menu', callback_data: 'menu_main' }]
            ]
          }
        });
        
      } else if (actionData.action.startsWith('post_')) {
        // Single platform posting
        const platform = actionData.platform;
        let result = '';
        
        if (platform === 'twitter' && this.twitterClient) {
          try {
            const tweetResult = await this.twitterClient.sendMessage(content);
            result = lang === 'es' ? 
              '✅ Publicado exitosamente en Twitter!' :
              '✅ Successfully posted to Twitter!';
          } catch (error) {
            result = lang === 'es' ? 
              `❌ Error al publicar en Twitter: ${error.message}` :
              `❌ Failed to post to Twitter: ${error.message}`;
          }
        } else if (platform === 'telegram' && this.telegramClient) {
          try {
            await this.telegramMessageManager.sendTextMessage(
              process.env.TELEGRAM_DEFAULT_CHAT_ID || chatId, 
              content
            );
            result = lang === 'es' ? 
              '✅ Publicado exitosamente en Telegram!' :
              '✅ Successfully posted to Telegram!';
          } catch (error) {
            result = lang === 'es' ? 
              `❌ Error al publicar en Telegram: ${error.message}` :
              `❌ Failed to post to Telegram: ${error.message}`;
          }
        } else {
          result = lang === 'es' ? 
            `⚠️ ${platform} no está configurado aún.` :
            `⚠️ ${platform} is not configured yet.`;
        }
        
        await this.bot.sendMessage(chatId, result, {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '🏠 Main Menu', callback_data: 'menu_main' }]
            ]
          }
        });
      }
      
    } catch (error) {
      logger.error(`Failed to process content input for ${chatId}`, error);
      const errorMessage = lang === 'es' ? 
        '❌ Error al procesar tu contenido. Intenta de nuevo.' :
        '❌ Failed to process your content. Please try again.';
      
      await this.bot.sendMessage(chatId, errorMessage, {
        reply_markup: {
          inline_keyboard: [
            [{ text: '🏠 Main Menu', callback_data: 'menu_main' }]
          ]
        }
      });
    }
  }

  async showScheduledContent(chatId, messageId) {
    try {
      const scheduledPosts = await ScheduledContent.findAll({
        where: { status: 'pending' },
        order: [['scheduledFor', 'ASC']],
        limit: 10
      });
      
      const lang = LanguageManager.getUserLanguage(chatId);
      
      if (scheduledPosts.length === 0) {
        const message = lang === 'es' ? 
          '📅 No tienes contenido programado.' :
          '📅 You have no scheduled content.';
        
        await this.bot.editMessageText(message, {
          chat_id: chatId,
          message_id: messageId,
          reply_markup: {
            inline_keyboard: [
              [{ text: '🔙 Back', callback_data: 'menu_schedule' }]
            ]
          }
        });
        return;
      }
      
      let message = lang === 'es' ? 
        '📅 <b>Contenido Programado:</b>\n\n' :
        '📅 <b>Scheduled Content:</b>\n\n';
      
      scheduledPosts.forEach((post, index) => {
        const date = new Date(post.scheduledFor).toLocaleString();
        message += `${index + 1}. <b>${post.platform}</b>\n`;
        message += `   📅 ${date}\n`;
        message += `   📝 ${post.content.substring(0, 50)}...\n\n`;
      });
      
      await this.bot.editMessageText(message, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔙 Back', callback_data: 'menu_schedule' }]
          ]
        }
      });
      
    } catch (error) {
      logger.error(`Failed to show scheduled content for ${chatId}`, error);
    }
  }

  async showQuickStatus(chatId, messageId) {
    const lang = LanguageManager.getUserLanguage(chatId);
    
    try {
      const pendingCount = await ScheduledContent.count({
        where: { status: 'pending' }
      });
      
      const completedCount = await ScheduledContent.count({
        where: { status: 'completed' }
      });
      
      const statusMessage = lang === 'es' ? 
        `📊 <b>Estado Rápido</b>\n\n⏰ Publicaciones pendientes: ${pendingCount}\n✅ Publicaciones completadas: ${completedCount}\n🤖 Bot: Funcionando correctamente` :
        `📊 <b>Quick Status</b>\n\n⏰ Pending posts: ${pendingCount}\n✅ Completed posts: ${completedCount}\n🤖 Bot: Running smoothly`;
      
      await this.bot.editMessageText(statusMessage, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🏠 Main Menu', callback_data: 'menu_main' }]
          ]
        }
      });
      
    } catch (error) {
      logger.error(`Failed to show quick status for ${chatId}`, error);
    }
  }

  async startLiveStream(chatId, messageId) {
    const lang = LanguageManager.getUserLanguage(chatId);
    
    try {
      if (!this.telegramLiveManager) {
        throw new Error('Live streaming not available');
      }
      
      const result = await this.telegramLiveManager.startLiveStream(chatId, {
        title: lang === 'es' ? 'Transmisión en Vivo' : 'Live Stream',
        description: lang === 'es' ? 'Iniciado desde el bot' : 'Started from bot',
        autoPin: true
      });
      
      const message = lang === 'es' ? 
        '🔴 ¡Transmisión en vivo iniciada!' :
        '🔴 Live stream started!';
      
      await this.bot.editMessageText(message, {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: {
          inline_keyboard: [
            [
              { text: '📡 End Stream', callback_data: 'live_end' },
              { text: '📢 Send Update', callback_data: 'live_update' }
            ],
            [{ text: '🏠 Main Menu', callback_data: 'menu_main' }]
          ]
        }
      });
      
    } catch (error) {
      logger.error(`Failed to start live stream for ${chatId}`, error);
      const errorMessage = lang === 'es' ? 
        '❌ Error al iniciar transmisión en vivo' :
        '❌ Failed to start live stream';
      
      await this.bot.editMessageText(errorMessage, {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔙 Back', callback_data: 'menu_live' }]
          ]
        }
      });
    }
  }

  async shutdown() {
    try {
      if (this.bot) {
        this.bot.stopPolling();
      }
      await dbConnection.close();
      logger.info('Enhanced Bot shutdown complete');
      process.exit(0);
    } catch (error) {
      logger.error('Error during enhanced bot shutdown', error);
      process.exit(1);
    }
  }
}

async function main() {
  try {
    const botManager = new EnhancedBotManager();
    await botManager.initialize();

    // Check command line arguments for mode
    const args = process.argv.slice(2);
    const mode = args[0] || 'enhanced';

    switch (mode) {
      case 'enhanced':
      case 'interactive':
        await botManager.startEnhancedInteractiveMode();
        break;
        
      case 'test':
        logger.info('Running enhanced bot test...');
        if (botManager.telegramClient) {
          const botInfo = await botManager.telegramClient.getBotInfo();
          logger.info(`✅ Enhanced Telegram Bot: @${botInfo.username}`);
        }
        logger.info('✅ Enhanced bot ready for deployment');
        await botManager.shutdown();
        break;
        
      default:
        logger.info('Enhanced Bot Modes:');
        logger.info('• npm run enhanced (default) - Enhanced interactive bot with menus');
        logger.info('• npm run enhanced test - Test enhanced bot functionality');
        await botManager.shutdown();
    }

  } catch (error) {
    handleError(error, logger);
    process.exit(1);
  }
}

// Handle graceful shutdown
process.on('SIGTERM', async () => {
  logger.info('SIGTERM received, shutting down enhanced bot gracefully...');
  try {
    await dbConnection.close();
    process.exit(0);
  } catch (error) {
    logger.error('Error during enhanced bot shutdown', error);
    process.exit(1);
  }
});

main().catch(error => {
  handleError(error, logger);
  process.exit(1);
});