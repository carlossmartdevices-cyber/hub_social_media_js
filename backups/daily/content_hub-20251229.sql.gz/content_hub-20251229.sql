--
-- PostgreSQL database dump
--

\restrict QRUmxVcRzdbrEDcRu8RJ3mel62POu1tzrsYKTAcRftAMZSKJTDW63wenHv6s4Xk

-- Dumped from database version 15.15
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: job_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_id character varying(255) NOT NULL,
    platform character varying(50) NOT NULL,
    status character varying(50),
    duration integer,
    error text,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT job_metrics_status_check CHECK (((status)::text = ANY ((ARRAY['success'::character varying, 'failure'::character varying])::text[])))
);


ALTER TABLE public.job_metrics OWNER TO postgres;

--
-- Name: platform_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.platform_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    platform character varying(50) NOT NULL,
    credentials text NOT NULL,
    is_active boolean DEFAULT true,
    last_validated timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT platform_credentials_platform_check CHECK (((platform)::text = ANY ((ARRAY['twitter'::character varying, 'telegram'::character varying, 'instagram'::character varying, 'tiktok'::character varying, 'facebook'::character varying, 'linkedin'::character varying, 'youtube'::character varying])::text[])))
);


ALTER TABLE public.platform_credentials OWNER TO postgres;

--
-- Name: platform_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.platform_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    platform_post_id uuid NOT NULL,
    platform character varying(50) NOT NULL,
    post_id character varying(255) NOT NULL,
    likes integer DEFAULT 0,
    shares integer DEFAULT 0,
    comments integer DEFAULT 0,
    views integer DEFAULT 0,
    engagement integer DEFAULT 0,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.platform_metrics OWNER TO postgres;

--
-- Name: platform_posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.platform_posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid NOT NULL,
    platform character varying(50) NOT NULL,
    platform_post_id character varying(255) NOT NULL,
    success boolean DEFAULT false,
    error text,
    published_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.platform_posts OWNER TO postgres;

--
-- Name: posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    platforms text[] NOT NULL,
    content jsonb NOT NULL,
    scheduled_at timestamp without time zone,
    published_at timestamp without time zone,
    status character varying(50) DEFAULT 'draft'::character varying,
    recurrence jsonb,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT posts_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'scheduled'::character varying, 'publishing'::character varying, 'published'::character varying, 'failed'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.posts OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'user'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'user'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: job_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job_metrics (id, job_id, platform, status, duration, error, "timestamp") FROM stdin;
\.


--
-- Data for Name: platform_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.platform_credentials (id, user_id, platform, credentials, is_active, last_validated, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: platform_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.platform_metrics (id, platform_post_id, platform, post_id, likes, shares, comments, views, engagement, "timestamp") FROM stdin;
\.


--
-- Data for Name: platform_posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.platform_posts (id, post_id, platform, platform_post_id, success, error, published_at, created_at) FROM stdin;
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.posts (id, user_id, platforms, content, scheduled_at, published_at, status, recurrence, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password_hash, name, role, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Name: job_metrics job_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_metrics
    ADD CONSTRAINT job_metrics_pkey PRIMARY KEY (id);


--
-- Name: platform_credentials platform_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_credentials
    ADD CONSTRAINT platform_credentials_pkey PRIMARY KEY (id);


--
-- Name: platform_credentials platform_credentials_user_id_platform_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_credentials
    ADD CONSTRAINT platform_credentials_user_id_platform_key UNIQUE (user_id, platform);


--
-- Name: platform_metrics platform_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_metrics
    ADD CONSTRAINT platform_metrics_pkey PRIMARY KEY (id);


--
-- Name: platform_posts platform_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_posts
    ADD CONSTRAINT platform_posts_pkey PRIMARY KEY (id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_job_metrics_job_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_job_metrics_job_id ON public.job_metrics USING btree (job_id);


--
-- Name: idx_job_metrics_platform; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_job_metrics_platform ON public.job_metrics USING btree (platform);


--
-- Name: idx_job_metrics_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_job_metrics_status ON public.job_metrics USING btree (status);


--
-- Name: idx_job_metrics_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_job_metrics_timestamp ON public.job_metrics USING btree ("timestamp");


--
-- Name: idx_platform_credentials_platform; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_platform_credentials_platform ON public.platform_credentials USING btree (platform);


--
-- Name: idx_platform_credentials_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_platform_credentials_user_id ON public.platform_credentials USING btree (user_id);


--
-- Name: idx_platform_metrics_platform_post_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_platform_metrics_platform_post_id ON public.platform_metrics USING btree (platform_post_id);


--
-- Name: idx_platform_metrics_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_platform_metrics_timestamp ON public.platform_metrics USING btree ("timestamp");


--
-- Name: idx_platform_posts_platform; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_platform_posts_platform ON public.platform_posts USING btree (platform);


--
-- Name: idx_platform_posts_post_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_platform_posts_post_id ON public.platform_posts USING btree (post_id);


--
-- Name: idx_posts_platforms; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_platforms ON public.posts USING gin (platforms);


--
-- Name: idx_posts_scheduled_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_scheduled_at ON public.posts USING btree (scheduled_at);


--
-- Name: idx_posts_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_status ON public.posts USING btree (status);


--
-- Name: idx_posts_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_user_id ON public.posts USING btree (user_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_is_active ON public.users USING btree (is_active);


--
-- Name: platform_credentials update_platform_credentials_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_platform_credentials_updated_at BEFORE UPDATE ON public.platform_credentials FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: posts update_posts_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_posts_updated_at BEFORE UPDATE ON public.posts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: platform_credentials platform_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_credentials
    ADD CONSTRAINT platform_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: platform_metrics platform_metrics_platform_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_metrics
    ADD CONSTRAINT platform_metrics_platform_post_id_fkey FOREIGN KEY (platform_post_id) REFERENCES public.platform_posts(id) ON DELETE CASCADE;


--
-- Name: platform_posts platform_posts_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_posts
    ADD CONSTRAINT platform_posts_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: posts posts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict QRUmxVcRzdbrEDcRu8RJ3mel62POu1tzrsYKTAcRftAMZSKJTDW63wenHv6s4Xk

