--
-- PostgreSQL database dump
--

\restrict VixGEkfFh0lkUWiCRXALseaF0OKsJUXE3YoGXWAereQgam8wB4upoNy0xUIAvZc

-- Dumped from database version 15.15
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: check_adult_content_restriction(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.check_adult_content_restriction() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- If niche.ageRestricted is true, ensure the post is marked appropriately
  IF (NEW.video_metadata -> 'niche' ->> 'ageRestricted')::boolean = true THEN
    -- You can add logic here to set additional flags or validations
    -- For now, we just log it
    RAISE NOTICE 'Adult content detected for post %', NEW.id;
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.check_adult_content_restriction() OWNER TO postgres;

--
-- Name: cleanup_expired_uploads(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cleanup_expired_uploads() RETURNS TABLE(cleaned_count bigint)
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_deleted bigint;
BEGIN
  DELETE FROM chunked_uploads
  WHERE expires_at < NOW();

  GET DIAGNOSTICS v_deleted = ROW_COUNT;

  RETURN QUERY SELECT v_deleted;
END;
$$;


ALTER FUNCTION public.cleanup_expired_uploads() OWNER TO postgres;

--
-- Name: update_chunked_uploads_timestamp(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_chunked_uploads_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_chunked_uploads_timestamp() OWNER TO postgres;

--
-- Name: update_telegram_channels_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_telegram_channels_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_telegram_channels_updated_at() OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

--
-- Name: update_video_jobs_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_video_jobs_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.completed_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_video_jobs_updated_at() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chunked_uploads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chunked_uploads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id character varying(255) NOT NULL,
    user_id uuid NOT NULL,
    file_name character varying(500) NOT NULL,
    file_size bigint NOT NULL,
    chunk_size integer NOT NULL,
    total_chunks integer NOT NULL,
    uploaded_chunks integer[] DEFAULT '{}'::integer[],
    checksum character varying(255),
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    metadata jsonb,
    processing_job_id character varying(255),
    error_message text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    CONSTRAINT chunked_uploads_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'uploading'::character varying, 'completed'::character varying, 'failed'::character varying, 'expired'::character varying])::text[]))),
    CONSTRAINT valid_chunk_count CHECK ((total_chunks > 0)),
    CONSTRAINT valid_chunk_size CHECK ((chunk_size > 0)),
    CONSTRAINT valid_file_size CHECK ((file_size > 0))
);


ALTER TABLE public.chunked_uploads OWNER TO postgres;

--
-- Name: active_uploads; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.active_uploads AS
 SELECT cu.id,
    cu.upload_id,
    cu.user_id,
    cu.file_name,
    cu.file_size,
    cu.chunk_size,
    cu.total_chunks,
    array_length(cu.uploaded_chunks, 1) AS uploaded_chunk_count,
    round((((array_length(cu.uploaded_chunks, 1))::numeric / (cu.total_chunks)::numeric) * (100)::numeric), 2) AS progress_percent,
    cu.status,
    cu.created_at,
    cu.expires_at
   FROM public.chunked_uploads cu
  WHERE (((cu.status)::text = ANY ((ARRAY['pending'::character varying, 'uploading'::character varying])::text[])) AND (cu.expires_at > now()));


ALTER VIEW public.active_uploads OWNER TO postgres;

--
-- Name: posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    platforms text[] NOT NULL,
    content jsonb NOT NULL,
    scheduled_at timestamp without time zone,
    published_at timestamp without time zone,
    status character varying(50) DEFAULT 'draft'::character varying,
    recurrence jsonb,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    platform_account_ids jsonb DEFAULT '{}'::jsonb,
    video_metadata jsonb,
    geo_restrictions jsonb,
    media_type character varying(50) DEFAULT 'text'::character varying,
    media_url text,
    thumbnail_url text,
    video_duration integer,
    video_size bigint,
    processing_status character varying(50) DEFAULT 'pending'::character varying,
    CONSTRAINT posts_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'scheduled'::character varying, 'publishing'::character varying, 'published'::character varying, 'failed'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.posts OWNER TO postgres;

--
-- Name: COLUMN posts.platform_account_ids; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.posts.platform_account_ids IS 'Maps platform to specific account ID to use for that platform (e.g., {"twitter": "uuid-here"})';


--
-- Name: COLUMN posts.video_metadata; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.posts.video_metadata IS 'JSON structure (UPDATED): {
  "title": "Video title",
  "description": "Video description (max 3 lines)",
  "alt_text": "Accessibility description",
  "hashtags": ["#tag1", "#tag2"],
  "cta": "Call to action text",
  "language": "es",
  "category": "tutorial",

  "performers": ["Carlos", "Miguel", "Juan"],
  "niche": {
    "primary": "gay",
    "tags": ["latino", "smoking", "pnp", "twink", "party"],
    "ageRestricted": true
  },

  "seo": {
    "title": "SEO optimized title (60-70 chars)",
    "metaDescription": "SEO meta description (150-160 chars)",
    "targetKeyword": "gay latino smoking pnp",
    "keywords": ["gay porn", "latino twinks", "smoking fetish", "pnp party"],
    "longTailQueries": ["hot latino guys smoking pnp", "gay party and play videos"],
    "voiceSearchQueries": ["where to find latino gay smoking content"]
  },

  "social": {
    "titleEN": "English social title",
    "descriptionEN": "English social description",
    "titleES": "Título en español",
    "descriptionES": "Descripción en español",
    "hashtagsEN": ["#GayLatino", "#SmokingFetish"],
    "hashtagsES": ["#LatinoGay", "#FeticheFumar"],
    "cta": "Check full video at..."
  },

  "hosting": {
    "previewUrl": "https://previews.pnptv.app/videos/...",
    "thumbnailUrl": "https://previews.pnptv.app/thumbs/...",
    "fullVideoUrl": "https://pnptv.app/watch/...",
    "cdnProvider": "cloudflare|aws|digitalocean"
  }
}';


--
-- Name: COLUMN posts.geo_restrictions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.posts.geo_restrictions IS 'JSON structure: {
  "type": "whitelist" | "blacklist",
  "countries": ["US", "MX", "ES"],
  "regions": ["California", "Texas"],
  "message": "This content is not available in your region"
}';


--
-- Name: COLUMN posts.video_duration; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.posts.video_duration IS 'Video duration in seconds. For adult content previews: MUST be between 15 and 45 seconds';


--
-- Name: adult_content_posts; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.adult_content_posts AS
 SELECT p.id,
    p.user_id,
    p.platforms,
    p.scheduled_at,
    p.published_at,
    p.status,
    (p.video_metadata ->> 'title'::text) AS title,
    (p.video_metadata ->> 'description'::text) AS description,
    (p.video_metadata -> 'performers'::text) AS performers,
    ((p.video_metadata -> 'niche'::text) -> 'tags'::text) AS niche_tags,
    ((p.video_metadata -> 'seo'::text) ->> 'targetKeyword'::text) AS target_keyword,
    ((p.video_metadata -> 'hosting'::text) ->> 'previewUrl'::text) AS preview_url,
    p.video_duration,
    p.processing_status,
    p.created_at,
    p.updated_at
   FROM public.posts p
  WHERE (((p.media_type)::text = 'video'::text) AND ((((p.video_metadata -> 'niche'::text) ->> 'ageRestricted'::text))::boolean = true));


ALTER VIEW public.adult_content_posts OWNER TO postgres;

--
-- Name: automated_action_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.automated_action_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    action_id uuid NOT NULL,
    platform character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    details jsonb,
    error text,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT automated_action_logs_status_check CHECK (((status)::text = ANY ((ARRAY['success'::character varying, 'failure'::character varying, 'skipped'::character varying])::text[])))
);


ALTER TABLE public.automated_action_logs OWNER TO postgres;

--
-- Name: automated_actions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.automated_actions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(50) NOT NULL,
    platforms text[] NOT NULL,
    config jsonb NOT NULL,
    is_enabled boolean DEFAULT true,
    last_executed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT automated_actions_type_check CHECK (((type)::text = ANY ((ARRAY['auto_reply_inbox'::character varying, 'auto_reply_mentions'::character varying, 'scheduled_promotion'::character varying, 'auto_like'::character varying, 'auto_follow'::character varying])::text[])))
);


ALTER TABLE public.automated_actions OWNER TO postgres;

--
-- Name: job_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_id character varying(255) NOT NULL,
    platform character varying(50) NOT NULL,
    status character varying(50),
    duration integer,
    error text,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT job_metrics_status_check CHECK (((status)::text = ANY ((ARRAY['success'::character varying, 'failure'::character varying])::text[])))
);


ALTER TABLE public.job_metrics OWNER TO postgres;

--
-- Name: platform_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.platform_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    platform character varying(50) NOT NULL,
    credentials text NOT NULL,
    is_active boolean DEFAULT true,
    last_validated timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    account_name character varying(255) NOT NULL,
    account_identifier character varying(255) NOT NULL,
    is_default boolean DEFAULT false,
    CONSTRAINT platform_credentials_platform_check CHECK (((platform)::text = ANY ((ARRAY['twitter'::character varying, 'telegram'::character varying, 'instagram'::character varying, 'tiktok'::character varying, 'facebook'::character varying, 'linkedin'::character varying, 'youtube'::character varying])::text[])))
);


ALTER TABLE public.platform_credentials OWNER TO postgres;

--
-- Name: COLUMN platform_credentials.account_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.platform_credentials.account_name IS 'User-friendly name for the account (e.g., "Personal Twitter", "Business X")';


--
-- Name: COLUMN platform_credentials.account_identifier; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.platform_credentials.account_identifier IS 'Unique identifier for the account (e.g., Twitter username, Instagram handle)';


--
-- Name: COLUMN platform_credentials.is_default; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.platform_credentials.is_default IS 'Whether this is the default account for posting when no specific account is selected';


--
-- Name: platform_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.platform_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    platform_post_id uuid NOT NULL,
    platform character varying(50) NOT NULL,
    post_id character varying(255) NOT NULL,
    likes integer DEFAULT 0,
    shares integer DEFAULT 0,
    comments integer DEFAULT 0,
    views integer DEFAULT 0,
    engagement integer DEFAULT 0,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.platform_metrics OWNER TO postgres;

--
-- Name: platform_posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.platform_posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid NOT NULL,
    platform character varying(50) NOT NULL,
    platform_post_id character varying(255) NOT NULL,
    success boolean DEFAULT false,
    error text,
    published_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.platform_posts OWNER TO postgres;

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schema_migrations (
    id integer NOT NULL,
    migration_name character varying(255) NOT NULL,
    applied_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.schema_migrations OWNER TO postgres;

--
-- Name: schema_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schema_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.schema_migrations_id_seq OWNER TO postgres;

--
-- Name: schema_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schema_migrations_id_seq OWNED BY public.schema_migrations.id;


--
-- Name: support_ticket_responses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.support_ticket_responses (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    responder_type character varying(50) NOT NULL,
    responder_id bigint,
    message text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.support_ticket_responses OWNER TO postgres;

--
-- Name: support_ticket_responses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.support_ticket_responses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.support_ticket_responses_id_seq OWNER TO postgres;

--
-- Name: support_ticket_responses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.support_ticket_responses_id_seq OWNED BY public.support_ticket_responses.id;


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.support_tickets (
    id integer NOT NULL,
    ticket_id character varying(255) NOT NULL,
    user_id bigint NOT NULL,
    telegram_username character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    message text NOT NULL,
    status character varying(50) DEFAULT 'open'::character varying,
    priority character varying(50) DEFAULT 'normal'::character varying,
    assigned_to uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    resolved_at timestamp without time zone
);


ALTER TABLE public.support_tickets OWNER TO postgres;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.support_tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.support_tickets_id_seq OWNER TO postgres;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.support_tickets_id_seq OWNED BY public.support_tickets.id;


--
-- Name: telegram_broadcast_results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.telegram_broadcast_results (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    broadcast_id uuid,
    channel_id uuid,
    success boolean DEFAULT false NOT NULL,
    message_id bigint,
    error_message text,
    sent_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.telegram_broadcast_results OWNER TO postgres;

--
-- Name: TABLE telegram_broadcast_results; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.telegram_broadcast_results IS 'Individual results for each channel in a broadcast';


--
-- Name: telegram_broadcasts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.telegram_broadcasts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    post_id uuid,
    type character varying(50) NOT NULL,
    content text NOT NULL,
    channels_count integer DEFAULT 0 NOT NULL,
    successful_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    telegram_file_id character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    CONSTRAINT telegram_broadcasts_type_check CHECK (((type)::text = ANY ((ARRAY['video'::character varying, 'text'::character varying, 'photo'::character varying])::text[])))
);


ALTER TABLE public.telegram_broadcasts OWNER TO postgres;

--
-- Name: TABLE telegram_broadcasts; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.telegram_broadcasts IS 'Tracks broadcast history and status';


--
-- Name: COLUMN telegram_broadcasts.telegram_file_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.telegram_broadcasts.telegram_file_id IS 'Telegram file_id for reusing uploaded media';


--
-- Name: telegram_channels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.telegram_channels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    chat_id character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    type character varying(50) NOT NULL,
    username character varying(255),
    is_active boolean DEFAULT true,
    last_broadcast_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT telegram_channels_type_check CHECK (((type)::text = ANY ((ARRAY['channel'::character varying, 'group'::character varying, 'supergroup'::character varying])::text[])))
);


ALTER TABLE public.telegram_channels OWNER TO postgres;

--
-- Name: TABLE telegram_channels; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.telegram_channels IS 'Stores Telegram channels and groups for broadcasting';


--
-- Name: COLUMN telegram_channels.chat_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.telegram_channels.chat_id IS 'Telegram chat ID (@username or numeric ID)';


--
-- Name: COLUMN telegram_channels.type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.telegram_channels.type IS 'Type of chat: channel, group, or supergroup';


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255),
    password_hash character varying(255),
    name character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'user'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    x_user_id character varying(255),
    x_username character varying(255),
    x_name character varying(255),
    x_profile_image text,
    telegram_id character varying(255),
    telegram_username character varying(255),
    telegram_first_name character varying(255),
    telegram_last_name character varying(255),
    telegram_photo_url text,
    auth_provider character varying(50) DEFAULT 'email'::character varying,
    provider_user_id character varying(255),
    avatar_url text,
    bio text,
    CONSTRAINT check_user_identity CHECK (((email IS NOT NULL) OR (x_user_id IS NOT NULL) OR (telegram_id IS NOT NULL) OR (provider_user_id IS NOT NULL))),
    CONSTRAINT users_auth_provider_check CHECK (((auth_provider)::text = ANY ((ARRAY['email'::character varying, 'x'::character varying, 'telegram'::character varying, 'google'::character varying])::text[]))),
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'user'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: COLUMN users.x_user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.x_user_id IS 'X (Twitter) user ID from OAuth';


--
-- Name: COLUMN users.telegram_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.telegram_id IS 'Telegram user ID from OAuth';


--
-- Name: COLUMN users.auth_provider; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.auth_provider IS 'Authentication provider: email, x, telegram, google';


--
-- Name: COLUMN users.provider_user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.provider_user_id IS 'Generic provider user ID for future OAuth providers';


--
-- Name: video_analytics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.video_analytics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid,
    platform character varying(50) NOT NULL,
    views integer DEFAULT 0,
    watch_time integer DEFAULT 0,
    completion_rate numeric(5,2),
    engagement_rate numeric(5,2),
    country_code character varying(2),
    device_type character varying(50),
    "timestamp" timestamp with time zone DEFAULT now()
);


ALTER TABLE public.video_analytics OWNER TO postgres;

--
-- Name: video_processing_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.video_processing_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid,
    original_url text NOT NULL,
    processed_url text,
    thumbnail_url text,
    status character varying(50) DEFAULT 'pending'::character varying,
    format character varying(20),
    resolution character varying(20),
    bitrate integer,
    size_before bigint,
    size_after bigint,
    compression_ratio numeric(5,2),
    error_message text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.video_processing_jobs OWNER TO postgres;

--
-- Name: schema_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schema_migrations ALTER COLUMN id SET DEFAULT nextval('public.schema_migrations_id_seq'::regclass);


--
-- Name: support_ticket_responses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_ticket_responses ALTER COLUMN id SET DEFAULT nextval('public.support_ticket_responses_id_seq'::regclass);


--
-- Name: support_tickets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets ALTER COLUMN id SET DEFAULT nextval('public.support_tickets_id_seq'::regclass);


--
-- Data for Name: automated_action_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.automated_action_logs (id, action_id, platform, status, details, error, executed_at) FROM stdin;
\.


--
-- Data for Name: automated_actions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.automated_actions (id, user_id, name, type, platforms, config, is_enabled, last_executed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chunked_uploads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chunked_uploads (id, upload_id, user_id, file_name, file_size, chunk_size, total_chunks, uploaded_chunks, checksum, status, metadata, processing_job_id, error_message, created_at, updated_at, expires_at) FROM stdin;
\.


--
-- Data for Name: job_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job_metrics (id, job_id, platform, status, duration, error, "timestamp") FROM stdin;
\.


--
-- Data for Name: platform_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.platform_credentials (id, user_id, platform, credentials, is_active, last_validated, created_at, updated_at, account_name, account_identifier, is_default) FROM stdin;
\.


--
-- Data for Name: platform_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.platform_metrics (id, platform_post_id, platform, post_id, likes, shares, comments, views, engagement, "timestamp") FROM stdin;
\.


--
-- Data for Name: platform_posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.platform_posts (id, post_id, platform, platform_post_id, success, error, published_at, created_at) FROM stdin;
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.posts (id, user_id, platforms, content, scheduled_at, published_at, status, recurrence, metadata, created_at, updated_at, platform_account_ids, video_metadata, geo_restrictions, media_type, media_url, thumbnail_url, video_duration, video_size, processing_status) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schema_migrations (id, migration_name, applied_at) FROM stdin;
1	001_initial_schema.sql	2026-01-29 19:50:52.993444
2	002_add_oauth_support.sql	2026-01-29 19:50:53.060957
3	002_multi_account_support.sql	2026-01-29 19:50:53.089087
4	003_video_support.sql	2026-01-29 19:50:53.107383
5	004_telegram_channels.sql	2026-01-29 19:50:53.172008
6	005_add_performers_and_niche_metadata.sql	2026-01-29 19:50:53.210742
7	005_automated_actions.sql	2026-01-29 19:50:53.267153
8	007_chunked_uploads.sql	2026-01-29 19:50:53.297768
9	008_support_tickets.sql	2026-01-29 19:50:53.360371
\.


--
-- Data for Name: support_ticket_responses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.support_ticket_responses (id, ticket_id, responder_type, responder_id, message, created_at) FROM stdin;
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.support_tickets (id, ticket_id, user_id, telegram_username, first_name, last_name, message, status, priority, assigned_to, created_at, updated_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: telegram_broadcast_results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.telegram_broadcast_results (id, broadcast_id, channel_id, success, message_id, error_message, sent_at) FROM stdin;
\.


--
-- Data for Name: telegram_broadcasts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.telegram_broadcasts (id, user_id, post_id, type, content, channels_count, successful_count, failed_count, status, telegram_file_id, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: telegram_channels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.telegram_channels (id, user_id, chat_id, title, type, username, is_active, last_broadcast_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password_hash, name, role, is_active, created_at, updated_at, x_user_id, x_username, x_name, x_profile_image, telegram_id, telegram_username, telegram_first_name, telegram_last_name, telegram_photo_url, auth_provider, provider_user_id, avatar_url, bio) FROM stdin;
\.


--
-- Data for Name: video_analytics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.video_analytics (id, post_id, platform, views, watch_time, completion_rate, engagement_rate, country_code, device_type, "timestamp") FROM stdin;
\.


--
-- Data for Name: video_processing_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.video_processing_jobs (id, post_id, original_url, processed_url, thumbnail_url, status, format, resolution, bitrate, size_before, size_after, compression_ratio, error_message, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Name: schema_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schema_migrations_id_seq', 9, true);


--
-- Name: support_ticket_responses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.support_ticket_responses_id_seq', 1, false);


--
-- Name: support_tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.support_tickets_id_seq', 1, false);


--
-- Name: automated_action_logs automated_action_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.automated_action_logs
    ADD CONSTRAINT automated_action_logs_pkey PRIMARY KEY (id);


--
-- Name: automated_actions automated_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.automated_actions
    ADD CONSTRAINT automated_actions_pkey PRIMARY KEY (id);


--
-- Name: chunked_uploads chunked_uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chunked_uploads
    ADD CONSTRAINT chunked_uploads_pkey PRIMARY KEY (id);


--
-- Name: chunked_uploads chunked_uploads_upload_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chunked_uploads
    ADD CONSTRAINT chunked_uploads_upload_id_key UNIQUE (upload_id);


--
-- Name: job_metrics job_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_metrics
    ADD CONSTRAINT job_metrics_pkey PRIMARY KEY (id);


--
-- Name: platform_credentials platform_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_credentials
    ADD CONSTRAINT platform_credentials_pkey PRIMARY KEY (id);


--
-- Name: platform_metrics platform_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_metrics
    ADD CONSTRAINT platform_metrics_pkey PRIMARY KEY (id);


--
-- Name: platform_posts platform_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_posts
    ADD CONSTRAINT platform_posts_pkey PRIMARY KEY (id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_migration_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_migration_name_key UNIQUE (migration_name);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (id);


--
-- Name: support_ticket_responses support_ticket_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_ticket_responses
    ADD CONSTRAINT support_ticket_responses_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_ticket_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_ticket_id_key UNIQUE (ticket_id);


--
-- Name: telegram_broadcast_results telegram_broadcast_results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telegram_broadcast_results
    ADD CONSTRAINT telegram_broadcast_results_pkey PRIMARY KEY (id);


--
-- Name: telegram_broadcasts telegram_broadcasts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telegram_broadcasts
    ADD CONSTRAINT telegram_broadcasts_pkey PRIMARY KEY (id);


--
-- Name: telegram_channels telegram_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telegram_channels
    ADD CONSTRAINT telegram_channels_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: video_analytics video_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.video_analytics
    ADD CONSTRAINT video_analytics_pkey PRIMARY KEY (id);


--
-- Name: video_processing_jobs video_processing_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.video_processing_jobs
    ADD CONSTRAINT video_processing_jobs_pkey PRIMARY KEY (id);


--
-- Name: idx_automated_action_logs_action_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_automated_action_logs_action_id ON public.automated_action_logs USING btree (action_id);


--
-- Name: idx_automated_action_logs_executed_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_automated_action_logs_executed_at ON public.automated_action_logs USING btree (executed_at);


--
-- Name: idx_automated_action_logs_platform; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_automated_action_logs_platform ON public.automated_action_logs USING btree (platform);


--
-- Name: idx_automated_action_logs_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_automated_action_logs_status ON public.automated_action_logs USING btree (status);


--
-- Name: idx_automated_actions_is_enabled; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_automated_actions_is_enabled ON public.automated_actions USING btree (is_enabled);


--
-- Name: idx_automated_actions_platforms; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_automated_actions_platforms ON public.automated_actions USING gin (platforms);


--
-- Name: idx_automated_actions_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_automated_actions_type ON public.automated_actions USING btree (type);


--
-- Name: idx_automated_actions_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_automated_actions_user_id ON public.automated_actions USING btree (user_id);


--
-- Name: idx_chunked_uploads_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_chunked_uploads_created_at ON public.chunked_uploads USING btree (created_at);


--
-- Name: idx_chunked_uploads_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_chunked_uploads_expires_at ON public.chunked_uploads USING btree (expires_at);


--
-- Name: idx_chunked_uploads_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_chunked_uploads_status ON public.chunked_uploads USING btree (status);


--
-- Name: idx_chunked_uploads_upload_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_chunked_uploads_upload_id ON public.chunked_uploads USING btree (upload_id);


--
-- Name: idx_chunked_uploads_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_chunked_uploads_user_id ON public.chunked_uploads USING btree (user_id);


--
-- Name: idx_job_metrics_job_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_job_metrics_job_id ON public.job_metrics USING btree (job_id);


--
-- Name: idx_job_metrics_platform; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_job_metrics_platform ON public.job_metrics USING btree (platform);


--
-- Name: idx_job_metrics_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_job_metrics_status ON public.job_metrics USING btree (status);


--
-- Name: idx_job_metrics_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_job_metrics_timestamp ON public.job_metrics USING btree ("timestamp");


--
-- Name: idx_platform_credentials_default; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_platform_credentials_default ON public.platform_credentials USING btree (user_id, platform, is_default) WHERE (is_default = true);


--
-- Name: idx_platform_credentials_platform; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_platform_credentials_platform ON public.platform_credentials USING btree (platform);


--
-- Name: idx_platform_credentials_unique_account; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_platform_credentials_unique_account ON public.platform_credentials USING btree (user_id, platform, account_identifier);


--
-- Name: idx_platform_credentials_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_platform_credentials_user_id ON public.platform_credentials USING btree (user_id);


--
-- Name: idx_platform_metrics_platform_post_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_platform_metrics_platform_post_id ON public.platform_metrics USING btree (platform_post_id);


--
-- Name: idx_platform_metrics_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_platform_metrics_timestamp ON public.platform_metrics USING btree ("timestamp");


--
-- Name: idx_platform_posts_platform; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_platform_posts_platform ON public.platform_posts USING btree (platform);


--
-- Name: idx_platform_posts_post_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_platform_posts_post_id ON public.platform_posts USING btree (post_id);


--
-- Name: idx_posts_media_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_media_type ON public.posts USING btree (media_type);


--
-- Name: idx_posts_media_type_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_media_type_status ON public.posts USING btree (media_type, processing_status) WHERE ((media_type)::text = 'video'::text);


--
-- Name: idx_posts_niche_tags; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_niche_tags ON public.posts USING gin ((((video_metadata -> 'niche'::text) -> 'tags'::text)));


--
-- Name: idx_posts_performers; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_performers ON public.posts USING gin (((video_metadata -> 'performers'::text)));


--
-- Name: idx_posts_platform_account_ids; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_platform_account_ids ON public.posts USING gin (platform_account_ids);


--
-- Name: idx_posts_platforms; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_platforms ON public.posts USING gin (platforms);


--
-- Name: idx_posts_processing_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_processing_status ON public.posts USING btree (processing_status);


--
-- Name: idx_posts_scheduled_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_scheduled_at ON public.posts USING btree (scheduled_at);


--
-- Name: idx_posts_scheduled_future; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_scheduled_future ON public.posts USING btree (scheduled_at) WHERE ((status)::text = 'scheduled'::text);


--
-- Name: idx_posts_seo_keywords; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_seo_keywords ON public.posts USING gin ((((video_metadata -> 'seo'::text) -> 'keywords'::text)));


--
-- Name: idx_posts_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_status ON public.posts USING btree (status);


--
-- Name: idx_posts_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posts_user_id ON public.posts USING btree (user_id);


--
-- Name: idx_support_ticket_responses_ticket_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_support_ticket_responses_ticket_id ON public.support_ticket_responses USING btree (ticket_id);


--
-- Name: idx_support_tickets_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_support_tickets_created_at ON public.support_tickets USING btree (created_at DESC);


--
-- Name: idx_support_tickets_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_support_tickets_status ON public.support_tickets USING btree (status);


--
-- Name: idx_support_tickets_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_support_tickets_user_id ON public.support_tickets USING btree (user_id);


--
-- Name: idx_telegram_broadcast_results_broadcast_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_telegram_broadcast_results_broadcast_id ON public.telegram_broadcast_results USING btree (broadcast_id);


--
-- Name: idx_telegram_broadcast_results_channel_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_telegram_broadcast_results_channel_id ON public.telegram_broadcast_results USING btree (channel_id);


--
-- Name: idx_telegram_broadcasts_post_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_telegram_broadcasts_post_id ON public.telegram_broadcasts USING btree (post_id);


--
-- Name: idx_telegram_broadcasts_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_telegram_broadcasts_status ON public.telegram_broadcasts USING btree (status);


--
-- Name: idx_telegram_broadcasts_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_telegram_broadcasts_user_id ON public.telegram_broadcasts USING btree (user_id);


--
-- Name: idx_telegram_channels_chat_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_telegram_channels_chat_id ON public.telegram_channels USING btree (chat_id);


--
-- Name: idx_telegram_channels_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_telegram_channels_user_id ON public.telegram_channels USING btree (user_id);


--
-- Name: idx_users_auth_provider; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_auth_provider ON public.users USING btree (auth_provider);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_is_active ON public.users USING btree (is_active);


--
-- Name: idx_users_provider_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_provider_user_id ON public.users USING btree (provider_user_id, auth_provider) WHERE (provider_user_id IS NOT NULL);


--
-- Name: idx_users_telegram_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_telegram_id ON public.users USING btree (telegram_id) WHERE (telegram_id IS NOT NULL);


--
-- Name: idx_users_telegram_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_telegram_username ON public.users USING btree (telegram_username);


--
-- Name: idx_users_x_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_x_user_id ON public.users USING btree (x_user_id) WHERE (x_user_id IS NOT NULL);


--
-- Name: idx_users_x_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_x_username ON public.users USING btree (x_username);


--
-- Name: idx_video_analytics_country; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_video_analytics_country ON public.video_analytics USING btree (country_code);


--
-- Name: idx_video_analytics_platform; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_video_analytics_platform ON public.video_analytics USING btree (platform);


--
-- Name: idx_video_analytics_post_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_video_analytics_post_id ON public.video_analytics USING btree (post_id);


--
-- Name: idx_video_jobs_post_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_video_jobs_post_id ON public.video_processing_jobs USING btree (post_id);


--
-- Name: idx_video_jobs_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_video_jobs_status ON public.video_processing_jobs USING btree (status);


--
-- Name: chunked_uploads chunked_uploads_update_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER chunked_uploads_update_timestamp BEFORE UPDATE ON public.chunked_uploads FOR EACH ROW EXECUTE FUNCTION public.update_chunked_uploads_timestamp();


--
-- Name: telegram_channels telegram_channels_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER telegram_channels_updated_at BEFORE UPDATE ON public.telegram_channels FOR EACH ROW EXECUTE FUNCTION public.update_telegram_channels_updated_at();


--
-- Name: automated_actions update_automated_actions_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_automated_actions_updated_at BEFORE UPDATE ON public.automated_actions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: platform_credentials update_platform_credentials_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_platform_credentials_updated_at BEFORE UPDATE ON public.platform_credentials FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: posts update_posts_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_posts_updated_at BEFORE UPDATE ON public.posts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: posts validate_adult_content; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER validate_adult_content BEFORE INSERT OR UPDATE ON public.posts FOR EACH ROW WHEN ((new.video_metadata IS NOT NULL)) EXECUTE FUNCTION public.check_adult_content_restriction();


--
-- Name: video_processing_jobs video_jobs_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER video_jobs_updated_at BEFORE UPDATE ON public.video_processing_jobs FOR EACH ROW WHEN ((((old.status)::text <> (new.status)::text) AND ((new.status)::text = ANY ((ARRAY['completed'::character varying, 'failed'::character varying])::text[])))) EXECUTE FUNCTION public.update_video_jobs_updated_at();


--
-- Name: automated_action_logs automated_action_logs_action_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.automated_action_logs
    ADD CONSTRAINT automated_action_logs_action_id_fkey FOREIGN KEY (action_id) REFERENCES public.automated_actions(id) ON DELETE CASCADE;


--
-- Name: automated_actions automated_actions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.automated_actions
    ADD CONSTRAINT automated_actions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chunked_uploads chunked_uploads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chunked_uploads
    ADD CONSTRAINT chunked_uploads_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: support_tickets fk_assigned_to; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT fk_assigned_to FOREIGN KEY (assigned_to) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: support_ticket_responses fk_ticket; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_ticket_responses
    ADD CONSTRAINT fk_ticket FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- Name: platform_credentials platform_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_credentials
    ADD CONSTRAINT platform_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: platform_metrics platform_metrics_platform_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_metrics
    ADD CONSTRAINT platform_metrics_platform_post_id_fkey FOREIGN KEY (platform_post_id) REFERENCES public.platform_posts(id) ON DELETE CASCADE;


--
-- Name: platform_posts platform_posts_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_posts
    ADD CONSTRAINT platform_posts_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: posts posts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: telegram_broadcast_results telegram_broadcast_results_broadcast_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telegram_broadcast_results
    ADD CONSTRAINT telegram_broadcast_results_broadcast_id_fkey FOREIGN KEY (broadcast_id) REFERENCES public.telegram_broadcasts(id) ON DELETE CASCADE;


--
-- Name: telegram_broadcast_results telegram_broadcast_results_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telegram_broadcast_results
    ADD CONSTRAINT telegram_broadcast_results_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.telegram_channels(id) ON DELETE CASCADE;


--
-- Name: telegram_broadcasts telegram_broadcasts_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telegram_broadcasts
    ADD CONSTRAINT telegram_broadcasts_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE SET NULL;


--
-- Name: telegram_broadcasts telegram_broadcasts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telegram_broadcasts
    ADD CONSTRAINT telegram_broadcasts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: telegram_channels telegram_channels_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telegram_channels
    ADD CONSTRAINT telegram_channels_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: video_analytics video_analytics_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.video_analytics
    ADD CONSTRAINT video_analytics_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: video_processing_jobs video_processing_jobs_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.video_processing_jobs
    ADD CONSTRAINT video_processing_jobs_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: TABLE adult_content_posts; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.adult_content_posts TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict VixGEkfFh0lkUWiCRXALseaF0OKsJUXE3YoGXWAereQgam8wB4upoNy0xUIAvZc

