require('dotenv').config();

module.exports = {
  accessToken: process.env.TIKTOK_ACCESS_TOKEN
};